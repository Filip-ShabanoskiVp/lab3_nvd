
// Your Vue code here....
var app = new Vue({
    el: '#app1',
    data: {
        message:"",
        has_uppercase:false,
        has_lowercase:false,
        has_number:false,
        has_special:false
    },
    methods: {
        check: function() {
            this.has_number = /\d/.test(this.message);
            this.has_special= /[!@#\$%\^\&*\)\(+=._-]/.test(this.message);
            this.has_uppercase=/[A-Z]/.test(this.message);
            this.has_lowercase=/[a-z]/.test(this.message);
        }
    }
});
